﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HttpClientTest
{
   public class Tweets
    {
        public long Id { get; set; }        
        public DateTime  Stamp { get; set; }  
        public string  Text { get; set; }
    }
}
