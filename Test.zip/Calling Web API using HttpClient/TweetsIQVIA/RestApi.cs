﻿using HttpClientTest;
using System;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace TweetsIQVIA
{
   public class RestApi
    {
       public static async Task<List<Tweets>> CallWebAPIAsync( DateTime startDate , DateTime endDate)
        {
            List<Tweets> tweetsDistinctResult = new List<Tweets>(); 

            using (var client = new HttpClient())
            {
                //client.BaseAddress = new Uri("https://badapi.iqvia.io/api/v1/Tweets?startDate=2018-04-28T04%3A07%3A56.271Z&endDate=2018-04-29T04%3A07%3A56.271Z");

                client.BaseAddress = new Uri("https://badapi.iqvia.io/swagger/");

                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
               

                //GET Method
                HttpResponseMessage response = await client.GetAsync("https://badapi.iqvia.io/api/v1/Tweets?startDate="+startDate+ "&endDate= " + endDate);
                if (response.IsSuccessStatusCode)
                {
                    string tweets = await response.Content.ReadAsStringAsync();

                    List<Tweets> tweetsResult = JsonConvert.DeserializeObject<List<Tweets>>(tweets);

                    tweetsDistinctResult = tweetsResult.GroupBy(p => p.Id).Select(g => g.First()).ToList();

                }              
                
            }

            return tweetsDistinctResult;

        }
    }
}
