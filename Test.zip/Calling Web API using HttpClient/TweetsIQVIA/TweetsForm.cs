﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TweetsIQVIA;

namespace HttpClientTest
{
    public partial class TweetsForm : Form
    {
        public TweetsForm()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime date = this.dateTimePicker1.Value;

            this.textBox1.Text = date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime startDate;

            DateTime enddate;

            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                 startDate = Convert.ToDateTime(textBox1.Text).ToUniversalTime();
            }

            else
            {
                throw new Exception("StartDate Can't be Null");
            }

            if (!string.IsNullOrEmpty(textBox2.Text))
            {
                 enddate = Convert.ToDateTime(textBox2.Text).ToUniversalTime();
            }

            else
            {
                throw new Exception("EndDate Can't be Null");
            }

            Collection<object> jsonList = new Collection<object>();

           

            Task.Run(() =>
            {
                Task<List<Tweets>> tweetsResult = RestApi.CallWebAPIAsync(startDate, enddate);

                jsonList = new Collection<object>();

                foreach (Tweets tweet in tweetsResult.Result)
                {
                    string x = string.Format("Id:{0},   Stamp:{1}    Text:{2}", tweet.Id, tweet.Stamp, tweet.Text);

                    AddListBoxItem(x);
                }
                             
                

                //listBox1.Items.Add(new ListBoxItem("clan", "sifOsoba"));

            });


           
        }


        private delegate void AddListBoxItemDelegate(object item);

        private void AddListBoxItem(object item)
        {
            if (this.listBox1.InvokeRequired)
            {
                // This is a worker thread so delegate the task.
                this.listBox1.Invoke(new AddListBoxItemDelegate(this.AddListBoxItem), item);
            }
            else
            {
                // This is the UI thread so perform the task.
                this.listBox1.Items.Add(item);
            }
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            DateTime date = this.dateTimePicker2.Value;

            this.textBox2.Text = date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        }
    }
}
